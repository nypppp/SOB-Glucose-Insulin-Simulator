# Model Glukosa-Insulin: Mode Normal (Pankreas Sehat)

Dokumentasi ini merangkum model matematis, sumber, parameter, modifikasi, dan hasil
verifikasi untuk **Mode Normal** pada simulator sistem glukosa-insulin. Dokumen ini
menjadi fondasi sebelum pengembangan Mode Diabetes (tanpa kontrol dan dengan
Artificial Pancreas/PID) serta visualisasi interaktif.

---

## 1. Ringkasan Model

Mode Normal merepresentasikan kondisi tubuh sehat, di mana pankreas secara alami
mensekresi insulin sebagai respons terhadap kenaikan glukosa darah. Sistem ini
merupakan **closed-loop** (loop tertutup) — glukosa memengaruhi sekresi insulin, dan
insulin balik memengaruhi glukosa.

### Pemetaan ke Block Diagram Kontrol

| Blok | Isi di Mode Normal |
|---|---|
| Input / Setpoint | `p5` (ambang glukosa) |
| Controller | Persamaan `dI/dt` (fungsi sekresi pankreas alami) |
| Process (Plant) | Persamaan `dG/dt` dan `dX/dt` (respons tubuh terhadap insulin) |
| Feedback path | `G(t)` dibaca balik ke suku `[G-p5]⁺` |
| Disturbance | `D(t)` (input makan) |

---

## 2. Persamaan Matematis

Sistem 3 persamaan diferensial nonlinear, closed-loop:

```
dG(t)/dt = -p1(G(t) - Gb) - X(t)·G(t) + D(t)

dX(t)/dt = -p2·X(t) + p3(I(t) - Ib)

dI(t)/dt = p6·[G(t) - p5]⁺ · τ(t) - n(I(t) - Ib)
```

**Keterangan variabel:**
- `G(t)` — konsentrasi glukosa plasma (mg/dL)
- `X(t)` — efek insulin aktif di jaringan remote (1/menit)
- `I(t)` — konsentrasi insulin plasma (μU/mL)
- `D(t)` — input gangguan makan (rate of glucose appearance)
- `τ(t)` — waktu lokal sejak G(t) terakhir melewati ambang p5 (lihat Bagian 4)
- `[x]⁺` — operator `max(x, 0)`

**Kondisi awal (baseline/istirahat):** `G(0)=Gb`, `X(0)=0`, `I(0)=Ib`

---

## 3. Sumber (Rantai Sitasi)

| Bagian Model | Sumber |
|---|---|
| Persamaan glukosa (`dG/dt`, `dX/dt`) — "Model VI" | Bergman, R.N., Ider, Y.Z., Bowden, C.R., & Cobelli, C. (1979). Quantitative estimation of insulin sensitivity. *American Journal of Physiology*, 236(6), E667–E677. |
| Persamaan insulin (`dI/dt`) + nilai parameter contoh subjek normal | Pacini, G., & Bergman, R.N. (1986). MINMOD: a computer program to calculate insulin sensitivity and pancreatic responsivity from the frequently sampled intravenous glucose tolerance test. *Computer Methods and Programs in Biomedicine*, 23(2), 113–122. |
| Penggabungan (*coupling*) kedua model jadi sistem closed-loop 3-persamaan; identifikasi bug equilibrium | Friis-Jensen, E. (2007). *Modeling and Simulation of Glucose-Insulin Metabolism*. B.Sc. Thesis, Technical University of Denmark (DTU). |
| Fungsi input makan `D(t) = A·t·e^(-t/τ)/τ²` (absorpsi 2-kompartemen berantai, konstanta transfer identik) | Hovorka, R., Canonico, V., Chassin, L.J., Haueter, U., Massi-Benedetti, M., Orsini Federici, M., Pieber, T.R., Schaller, H.C., Schaupp, L., Vering, T., & Wilinska, M.E. (2004). Nonlinear model predictive control of glucose concentration in subjects with type 1 diabetes. *Physiological Measurement*, 25(4), 905–920 — Persamaan (4). Nilai τ = tmax,G = 40 menit (Tabel 1 paper yang sama). |

**Catatan penting:** Persamaan glukosa dan insulin *aslinya* dirancang **open-loop**
untuk analisis data IVGTT (Intravenous Glucose Tolerance Test) — insulin/glukosa
terukur dipakai sebagai *input*, bukan hasil simulasi timbal-balik. Coupling menjadi
sistem closed-loop adalah langkah tambahan (Friis-Jensen, 2007), bukan bagian dari
paper asli Bergman (1979) maupun Pacini & Bergman (1986).

---

## 4. Parameter

### Parameter Model (dari Pacini & Bergman, 1986 — Fig. 3A/3B, dataset "NORMAL.DAT")

| Simbol | Nilai | Satuan | Arti Fisiologis |
|---|---|---|---|
| p1 | 0.03082 | 1/min | Glucose effectiveness (SG) |
| p2 | 0.02093 | 1/min | Peluruhan efek insulin aktif |
| p3 | 1.062×10⁻⁵ | L/(min²·mU) | Insulin sensitivity |
| n | 0.3 | 1/min | Clearance insulin plasma |
| p6 (γ) | 0.003349 | — | Laju respons pankreas |
| Gb | 92 | mg/dL | Glukosa basal |
| Ib | 7.3 | μU/mL | Insulin basal |

### Parameter yang DIMODIFIKASI dari nilai asli paper

| Simbol | Nilai Asli Paper | Nilai Dipakai Simulator | Alasan |
|---|---|---|---|
| p5 | 89.5 | **94** | p5 asli < Gb menyebabkan sistem tidak bisa mencapai equilibrium (lihat Bagian 5) |
| Suku waktu di dI/dt | `t` (absolut, sejak simulasi/eksperimen mulai) | **τ (lokal, reset tiap episode)** | `t` absolut menyebabkan sekresi insulin tumbuh tak terbatas / tidak konsisten pada simulasi jangka panjang dengan banyak episode (lihat Bagian 5) |

---

## 5. Modifikasi & Justifikasi

### 5.1 Modifikasi p5: 89.5 → 94

**Masalah:** Pembuktian analitik menunjukkan bahwa titik equilibrium (G=Gb, X=0, I=Ib)
hanya valid jika `p5 ≥ Gb`:

```
Di titik (G=Gb, I=Ib):  dI/dt = p6·[Gb - p5]⁺·τ

Jika p5 ≥ Gb  →  [Gb-p5]⁺ = 0  →  dI/dt = 0   ✓ equilibrium tercapai
Jika p5 < Gb  →  [Gb-p5]⁺ > 0  →  dI/dt ≠ 0   ✗ equilibrium TIDAK tercapai
```

Nilai asli paper (p5=89.5) lebih kecil dari Gb=92, sehingga sistem tidak akan pernah
diam meski tanpa gangguan apapun — insulin akan terus "bocor" naik. Ini tidak masalah
di paper asli (yang hanya fit data 182 menit sekali jalan), tapi jadi masalah untuk
simulasi closed-loop kontinu.

**Solusi:** p5 dinaikkan menjadi 94 (> Gb=92).

### 5.2 Modifikasi suku waktu: t absolut → τ lokal

**Masalah:** Suku `p6·[G-p5]⁺·t` merepresentasikan sekresi insulin fase-kedua
(second-phase), yang seharusnya bergantung pada **berapa lama episode glukosa
tinggi SAAT INI berlangsung** — bukan "berapa lama sejak simulasi dimulai". Jika
memakai `t` absolut, makan yang identik namun terjadi di menit ke-10 vs menit
ke-800 dalam simulasi menghasilkan respons insulin yang jauh berbeda (dibuktikan:
29,5 vs 102,3 μU/mL — beda 3,5×), padahal gangguannya sama persis.

**Solusi:** Ganti `t` dengan `τ` — waktu lokal yang **direset ke 0** setiap kali
`G(t)` turun ≤ p5, dan bertambah selama `G(t)` > p5.

---

## 6. Verifikasi

### 6.1 Verifikasi Analitik (Syarat Equilibrium)
Dibuktikan aljabar bahwa `p5 ≥ Gb` adalah syarat perlu dan cukup (bersama `dG/dt`
dan `dX/dt` yang otomatis nol di titik basal) agar (Gb, 0, Ib) menjadi titik
equilibrium yang valid.

### 6.2 Verifikasi Numerik — Uji Diam (Lapis 2)
Simulasi 1000 menit dari kondisi awal G(0)=Gb, X(0)=0, I(0)=Ib, **tanpa gangguan**.

| Variabel | Deviasi Maksimum dari Baseline |
|---|---|
| G(t) | 0.000000 mg/dL |
| X(t) | 0.00000000 |
| I(t) | 0.000000 μU/mL |

✅ **Lolos** — sistem benar-benar diam, tidak drift.

### 6.3 Verifikasi Numerik — Uji Gangguan lalu Kembali (Lapis 3)
Simulasi 1000 menit dengan 1× trigger makan di menit ke-60.

| Metrik | Hasil |
|---|---|
| Glukosa puncak | 122.55 mg/dL @ t=120.5 menit |
| Insulin puncak | 27.13 μU/mL @ t=142.0 menit (delay 21.5 menit dari puncak glukosa) |
| Glukosa akhir (t=1000 menit) | 92.0000 mg/dL (selisih dari Gb: 0.000002 mg/dL) |

✅ **Lolos** — kembali stabil sempurna ke baseline, termasuk pola *undershoot*
realistis sebelum stabil (konsisten dengan fenomena yang dilaporkan di Bergman
et al., 1979).

### 6.4 Verifikasi Konsistensi τ Lokal (Time-Shift Invariance)
Makan identik ditrigger di 6 titik waktu berbeda (t=10, 100, 300, 500, 800, 1500
menit).

| Titik Waktu Makan | G Puncak | I Puncak |
|---|---|---|
| Semua titik (10–1500) | 122.55 mg/dL | 27.13 μU/mL |

✅ **Lolos** — hasil identik di semua titik waktu, membuktikan τ lokal
menghilangkan ketergantungan artifisial pada "jam berapa sekarang".

### 6.5 Validasi Implementasi terhadap Data Paper
Model glukosa (`dG/dt`, `dX/dt`) diuji **open-loop** (insulin = data pengukuran asli
dari paper, bukan hasil simulasi kita) dan dibandingkan dengan hasil fit resmi paper
(Fig. 3A, kolom COMP.GLU).

**RMSE = 1.36 mg/dL** — sangat kecil, mengonfirmasi implementasi model glukosa
kita benar dan sesuai paper.

Saat diuji **closed-loop penuh** (insulin dari simulasi kita sendiri via τ lokal)
dibandingkan data mentah (dengan alignment waktu +4 menit dan eksklusi 4 titik
awal yang di-zero-weight oleh paper karena fase mixing ekstraseluler):

**RMSE = 10.02 mg/dL** — selisih ini wajar dan diharapkan, karena fungsi sekresi
pankreas adalah model/pendekatan matematis, bukan replikasi data insulin individu
pasien tertentu.

### Ringkasan Status Verifikasi

| # | Uji | Hasil |
|---|---|---|
| 1 | Analitik (syarat equilibrium) | ✅ Terbukti aljabar |
| 2 | Numerik — uji diam | ✅ Deviasi 0.000000 |
| 3 | Numerik — uji kembali stabil | ✅ Kembali ke baseline (selisih 0.000002) |
| 4 | Konsistensi τ lokal | ✅ Identik di semua titik waktu |
| 5 | Validasi vs data paper (model glukosa) | ✅ RMSE 1.36 mg/dL |
| 6 | Validasi vs data paper (closed-loop penuh) | ⚠️ RMSE 10.02 mg/dL (wajar) |

---

## 7. Perilaku Fisiologis yang Berhasil Direproduksi

- Glukosa naik ~30 mg/dL setelah makan, puncak ~60 menit pasca-makan
- Insulin menyusul naik dengan delay ~21.5 menit dari puncak glukosa (konsisten
  dengan pola first/second-phase insulin release)
- Sedikit *undershoot* sebelum stabil kembali ke baseline
- Kembali stabil sempurna tanpa osilasi liar, baik setelah gangguan tunggal maupun
  ketika diuji pada berbagai titik waktu simulasi

---

## 8. Verifikasi Sumber Fungsi Input Makan D(t)

Fungsi `D(t)` diverifikasi langsung ke PDF paper asli. Persamaan (4) di
Hovorka dkk. (2004):

```
UG(t) = DG · AG · t · e^(-t/tmax,G) / t²max,G
```

Perbandingan suku-per-suku dengan kode simulator:

| Hovorka (2004) | Simulator | Status |
|---|---|---|
| `DG·AG` (karbohidrat × bioavailabilitas) | `A` (amplitudo porsi makan) | Setara secara bentuk, digabung menjadi satu konstanta |
| `t` | `dtSince` (waktu sejak makan) | Identik |
| `e^(-t/tmax,G)` | `e^(-dtSince/τ_meal)` | Identik |
| `1/t²max,G` (normalisasi) | `1/τ_meal²` | Identik |
| `tmax,G = 40 min` | `mealTau = 40` | Identik |

Bentuk tersebut adalah solusi analitik dua kompartemen berantai dengan laju
transfer identik:

```
dD1/dt = cho - D1/tmax
dD2/dt = D1/tmax - D2/tmax
UG     = D2/tmax
```

**Catatan koreksi sumber:**

- Fisher (1991) tidak memakai bentuk ini; paper tersebut memakai
  `P(t) = B·exp(-kt)`, yaitu eksponensial sederhana.
- Urbina dkk. (2020) memakai `a0·exp(-b0·t)`.
- Lehmann & Deutsch (1992) memakai fungsi pengosongan lambung
  trapezoidal/segitiga.
- Hovorka dkk. (2004) adalah sumber yang cocok secara literal dengan bentuk
  fungsi yang digunakan simulator.

**Batas verifikasi:** bentuk fungsi dan `mealTau = 40` menit telah didukung
oleh Hovorka, tetapi amplitudo `A = 80/150/220` masih berupa skala kasar agar
respons terlihat wajar pada gabungan parameter Bergman–Pacini. Nilai tersebut
bukan konversi gram karbohidrat. Hovorka menggunakan `DG·AG` dalam satuan
model yang berbeda.

**Exercise tidak menjadi bagian model.** Perubahan sementara `p3` yang pernah
direncanakan belum memiliki rujukan dan validasi yang memadai, sehingga tidak
boleh disebut sebagai representasi fisiologis olahraga. Exercise hanya dapat
ditambahkan kembali setelah memiliki model, parameter, dan pengujian tersendiri.

---

## 9. Parameter Final untuk Implementasi Visualisasi

```python
p1 = 0.03082
p2 = 0.02093
p3 = 1.062e-5
n  = 0.3
p6 = 0.003349
Gb = 92.0
Ib = 7.3
p5 = 94.0        # dimodifikasi dari 89.5
G0 = 92.0        # mulai dari baseline (bukan G0=287 ala IVGTT)
X0 = 0.0
I0 = 7.3         # = Ib, mulai dari baseline

# Suku waktu pakai tau lokal (reset saat G <= p5), BUKAN t absolut
```

---

## 10. Rancangan Mode Diabetes Tipe 1 Tanpa PID

> **Status:** spesifikasi riset awal; belum diimplementasikan dan belum melewati
> verifikasi numerik. Mode ini sengaja dibatasi pada terapi insulin manual
> (*open-loop*), bukan Artificial Pancreas atau PID.

### 10.1 Tujuan dan ruang lingkup

Mode ini merepresentasikan penderita diabetes tipe 1 (T1D) yang tidak memiliki
sekresi insulin endogen yang memadai. Insulin diberikan dari luar tubuh sebagai:

- **basal**, yaitu infus konstan untuk kebutuhan insulin di antara waktu makan;
- **bolus makan**, yaitu dosis manual pada waktu yang dipilih pengguna; dan
- **bolus koreksi**, yaitu dosis manual untuk mengoreksi hiperglikemia.

Tidak ada hubungan otomatis dari pengukuran glukosa ke dosis insulin. Karena itu,
mode ini disebut *open-loop*. Pengguna dapat memilih makan tanpa bolus, memberi
bolus tepat waktu, memberi bolus terlambat, atau memberi dosis berlebih.

Mode ini bukan model ketoasidosis diabetik dan tidak ditujukan untuk menghitung
dosis insulin klinis bagi pasien nyata.

### 10.2 Dasar ilmiah terapi basal-bolus

Terapi penggantian insulin pada T1D secara fisiologis terdiri dari insulin basal,
insulin waktu makan, dan insulin koreksi. Terapi ini diberikan melalui beberapa
suntikan harian atau *continuous subcutaneous insulin infusion* (CSII), yaitu
pompa yang memberikan basal secara kontinu dan bolus makan secara manual.

Dasar peer-reviewed:

1. Holt, R.I.G., DeVries, J.H., Hess-Fischl, A., et al. (2021). *The management
   of type 1 diabetes in adults: A consensus report by the American Diabetes
   Association (ADA) and the European Association for the Study of Diabetes
   (EASD).* Diabetologia, 64, 2609-2652.
   DOI: https://doi.org/10.1007/s00125-021-05568-3
2. The Diabetes Control and Complications Trial Research Group (1993). *The
   effect of intensive treatment of diabetes on the development and progression
   of long-term complications in insulin-dependent diabetes mellitus.* New
   England Journal of Medicine, 329, 977-986.
   DOI: https://doi.org/10.1056/NEJM199309303291401

Kedua sumber tersebut mendukung keberadaan input insulin manual pada simulator.
Nilai dosis pada simulator tetap harus dikalibrasi terhadap model dan tidak boleh
ditafsirkan sebagai rekomendasi medis.

### 10.3 Keputusan struktur model T1D v2

Percobaan awal T1D v1 memakai model glukosa `G-X` Mode Normal dan hanya mengganti
sekresi pankreas dengan absorpsi insulin subkutan. Model lima-state tersebut
stabil secara matematis, tetapi gagal membedakan keadaan T1D dari Mode Normal:

- penghentian insulin hanya menghasilkan equilibrium sekitar `104.57 mg/dL`; dan
- makan `A = 150` tanpa bolus hanya mencapai sekitar `127.14 mg/dL`, sedangkan
  Mode Normal mencapai sekitar `122.55 mg/dL`.

Penyebabnya adalah suku `-p1(G-Gb)`, yang tetap menarik glukosa kembali ke
baseline walaupun insulin hampir tidak tersedia. Karena itu, T1D v2 tidak lagi
memakai persamaan glukosa Bergman-Pacini Mode Normal. T1D v2 memakai seluruh
subsistem glukosa, insulin, dan aksi insulin dari Hovorka dkk. (2004).

Mode Normal tetap memakai persamaannya sendiri dan tidak diubah oleh keputusan
ini.

### 10.4 Konvensi state dan satuan

T1D v2 memiliki delapan state:

```text
Q1, Q2, S1, S2, I, x1, x2, x3
```

| State | Arti |
|---|---|
| `Q1` | Massa glukosa pada kompartemen plasma/accessible |
| `Q2` | Massa glukosa pada kompartemen jaringan/non-accessible |
| `S1`, `S2` | Depot absorpsi insulin subkutan |
| `I` | Konsentrasi insulin plasma |
| `x1` | Efek insulin pada distribusi/transport glukosa |
| `x2` | Efek insulin pada disposal glukosa |
| `x3` | Efek insulin pada produksi glukosa endogen |

Implementasi awal sebaiknya memakai bentuk ternormalisasi per kilogram seperti
paper: `Q1` dan `Q2` dalam mmol/kg, `VG` dan `VI` dalam L/kg, laju glukosa dalam
mmol/kg/menit, insulin dalam mU/L, serta laju insulin dalam mU/kg/menit.
`1 mU/L` bernilai numerik sama dengan `1 microU/mL`.

Konsentrasi glukosa internal dihitung dalam mmol/L:

```text
G(t) = Q1(t) / VG
```

Untuk tampilan UI:

```text
G_mg_dL(t) = 18.0182 * G_mmol_L(t)
```

### 10.5 Subsistem glukosa Hovorka

```text
dQ1/dt = -[F01c/(VG*G) + x1]Q1
          + k12*Q2 - FR + UG + EGP0*(1 - x3)

dQ2/dt = x1*Q1 - (k12 + x2)Q2

G = Q1/VG
```

`F01c` adalah penggunaan glukosa yang tidak bergantung pada insulin dan dikoreksi
pada konsentrasi glukosa rendah:

```text
F01c = F01                  jika G >= 4.5 mmol/L
F01c = F01*(G/4.5)          jika G <  4.5 mmol/L
```

`FR` adalah ekskresi glukosa melalui ginjal, yang aktif di atas ambang
`9 mmol/L` atau sekitar `162 mg/dL`:

```text
FR = 0.003*(G - 9)*VG       jika G >= 9 mmol/L
FR = 0                      jika G <  9 mmol/L
```

Suku `EGP0*(1-x3)` merepresentasikan produksi glukosa endogen, terutama dari
hati. Inilah salah satu perbedaan penting dari model T1D v1.

### 10.6 Input makanan: bentuk sama, skala dan satuan berbeda

Input makanan T1D menggunakan persamaan (4) Hovorka:

```text
tauMeal = t - tMeal

UG(t) = DG*AG*tauMeal*exp(-tauMeal/tmaxG)/(tmaxG^2), jika tauMeal >= 0
UG(t) = 0,                                             jika tauMeal < 0
```

Persamaan tersebut mempunyai bentuk kernel yang sama dengan fungsi Mode Normal:

```text
D(t) = A*tauMeal*exp(-tauMeal/tau)/(tau^2)
```

Pemetaan bentuknya adalah:

```text
A   <-> DG*AG
tau <-> tmaxG
```

Jadi, bentuk kurva makanan lama memang berasal dari Hovorka. Perbedaannya bukan
pada bentuk persamaan, tetapi pada definisi amplitudo, satuan, dan state tujuan:

- Mode Normal memakai `A = 80/150/220` sebagai amplitudo internal dan `D(t)`
  langsung masuk ke `dG/dt`;
- Mode T1D memakai `DG` sebagai dosis karbohidrat dalam mmol/kg, mengalikan
  bioavailabilitas `AG`, dan memasukkan `UG` ke persamaan massa `dQ1/dt`.

Konversi gram karbohidrat menjadi `DG`, dengan pendekatan karbohidrat sebagai
ekuivalen glukosa, adalah:

```text
DG [mmol/kg] = carbsGram*1000/(180.16*weightKg)
```

Parameter Hovorka:

```text
AG    = 0.8
tmaxG = 40 min
```

Untuk beberapa kejadian makan, `UG_total(t)` adalah jumlah kontribusi semua
makanan yang sudah dimulai. Input `80/150/220` milik Mode Normal tidak boleh
dianggap sebagai gram karbohidrat dan tidak boleh dipakai langsung sebagai `DG`.

### 10.7 Subsistem absorpsi dan eliminasi insulin

```text
dS1/dt = u(t) - S1/tmaxI

dS2/dt = S1/tmaxI - S2/tmaxI

UI(t)  = S2/tmaxI

dI/dt  = UI/VI - ke*I
```

Input insulin manual:

```text
u(t) = uBasal(t) + uBolus(t)
```

`uBasal` bersifat kontinu. `uBolus` adalah dosis selama interval pendek pada
waktu yang dipilih pengguna. Makan tidak otomatis memberikan bolus. Tidak ada
sekresi insulin endogen dan tidak ada jalur `G -> pankreas -> I`.

Jika basal konstan, equilibrium subsistem insulin memenuhi:

```text
S1b = uBasal*tmaxI
S2b = uBasal*tmaxI
Ib  = uBasal/(VI*ke)
```

Untuk bolus `B` unit pada subjek dengan berat `W` kg, jumlah insulin yang masuk
ke depot adalah:

```text
bolus_mU_per_kg = B*1000/W
```

Jika bolus diterapkan selama satu langkah waktu `dt`, laju inputnya harus dibagi
dengan `dt` agar integral dosis tetap sama saat `dt` berubah.

### 10.8 Subsistem aksi insulin

```text
dx1/dt = -ka1*x1 + kb1*I
dx2/dt = -ka2*x2 + kb2*I
dx3/dt = -ka3*x3 + kb3*I
```

Paper memberikan sensitivitas alternatif `SIT`, `SID`, dan `SIE`, dengan:

```text
kb1 = ka1*SIT
kb2 = ka2*SID
kb3 = ka3*SIE
```

`x1`, `x2`, dan `x3` harus bereaksi terhadap insulin plasma yang telah melalui
penundaan absorpsi `S1-S2`; bolus tidak boleh memengaruhi glukosa secara instan.

### 10.9 Parameter populasi awal

| Parameter | Nilai awal | Satuan |
|---|---:|---|
| `k12` | 0.066 | /menit |
| `ka1` | 0.006 | /menit |
| `ka2` | 0.060 | /menit |
| `ka3` | 0.030 | /menit |
| `ke` | 0.138 | /menit |
| `VI` | 0.12 | L/kg |
| `VG` | 0.16 | L/kg |
| `AG` | 0.8 | tanpa satuan |
| `tmaxG` | 40 | menit |
| `tmaxI` | 55 | menit |
| `SIT` | `51.2e-4` | /menit per mU/L |
| `SID` | `8.2e-4` | /menit per mU/L |
| `SIE` | `520e-4` | per mU/L |
| `EGP0` | 0.0161 | mmol/kg/menit |
| `F01` | 0.0097 | mmol/kg/menit |

Nilai tersebut adalah nilai populasi awal dari Hovorka, bukan dosis personal
untuk pengguna. Berat badan diperlukan untuk mengonversi input gram dan unit
menjadi besaran per kilogram.

Sumber model dan parameter:

- Hovorka, R., Canonico, V., Chassin, L.J., et al. (2004). *Nonlinear model
  predictive control of glucose concentration in subjects with type 1 diabetes.*
  Physiological Measurement, 25(4), 905-920.
  DOI: https://doi.org/10.1088/0967-3334/25/4/010

### 10.10 Kondisi awal dan equilibrium

Simulasi tidak boleh dimulai dengan menebak `Q1`, `Q2`, atau state aksi insulin
secara terpisah. Untuk target glukosa puasa dan basal yang dipilih:

1. hitung equilibrium `S1`, `S2`, dan `I` dari basal;
2. hitung equilibrium `x1`, `x2`, dan `x3` dari `dxi/dt = 0`;
3. selesaikan `dQ1/dt = 0` dan `dQ2/dt = 0` tanpa makanan untuk `Q1` dan `Q2`;
4. pastikan `Q1/VG` sama dengan target glukosa yang konsisten dengan basal; dan
5. gunakan hasil equilibrium sebagai seluruh state awal.

Jika target glukosa dan basal tidak menghasilkan equilibrium yang sama, salah
satunya harus dicari secara numerik. Memaksa keduanya secara terpisah akan
menciptakan transien palsu pada awal simulasi.

### 10.11 Skenario demonstrasi yang dituju

| Skenario | Input pengguna | Perilaku yang diharapkan |
|---|---|---|
| Basal stabil | Basal aktif, tanpa makan | Sistem tetap di sekitar equilibrium |
| Makan tanpa bolus | Karbohidrat, bolus 0 | Glukosa meningkat jelas dan bertahan lebih lama |
| Bolus tepat waktu | Bolus dan makan berdekatan | Lonjakan glukosa lebih terkendali |
| Bolus terlambat | Makan lebih dahulu | Puncak dan paparan hiperglikemia lebih besar |
| Bolus berlebih | Makanan kecil, bolus besar | Risiko hipoglikemia akibat insulin aktif |
| Basal dihentikan | `uBasal = 0` | Insulin dan aksi insulin turun; produksi glukosa hati meningkat |

Mode ini tidak memodelkan keton, ketoasidosis, dehidrasi, perubahan hormon
kontraregulasi, atau perjalanan penyakit tanpa terapi selama beberapa hari.

### 10.12 Verifikasi wajib sebelum implementasi UI

T1D v2 belum dianggap siap untuk UI sebelum melewati seluruh uji berikut:

1. **Equilibrium basal:** seluruh delapan state tidak drift tanpa makanan.
2. **Neraca makanan:** integral `UG` harus sama dengan `DG*AG` dalam toleransi
   numerik.
3. **Neraca bolus:** integral `uBolus` harus sama dengan dosis yang diminta dan
   tidak bergantung pada `dt`.
4. **Penghentian basal:** `I`, `x1`, `x2`, dan `x3` menurun, sedangkan glukosa
   meningkat karena penekanan `EGP` berkurang.
5. **Makan tanpa bolus:** menghasilkan hiperglikemia yang jelas, bukan respons
   yang hampir sama dengan Mode Normal.
6. **Dosis-respons:** bolus yang meningkat menurunkan puncak atau AUC glukosa
   secara konsisten dalam rentang uji.
7. **Waktu bolus:** bolus terlambat menghasilkan paparan hiperglikemia lebih
   besar daripada bolus tepat waktu.
8. **Overdosis:** dosis berlebih dapat menimbulkan hipoglikemia tanpa membuat
   massa glukosa atau insulin negatif.
9. **Fungsi potongan:** uji khusus di sekitar `G = 4.5` dan `G = 9 mmol/L` untuk
   memastikan `F01c` dan `FR` tidak salah cabang.
10. **Konvergensi numerik:** hasil stabil saat `dt` diperkecil.
11. **Uji satuan:** gram, mmol, kg, U, mU, liter, menit, mmol/L, dan mg/dL
    diperiksa secara eksplisit.

### 10.13 Status implementasi

- Model hibrida T1D v1 lima-state dinyatakan **tidak digunakan**.
- Spesifikasi T1D v2 Hovorka delapan-state sudah ditetapkan dalam dokumen ini.
- T1D v2 belum diimplementasikan pada `script.js` dan belum diverifikasi secara
  numerik.
- Skrip `verification/t1d-v1.js` hanya merekam percobaan lama dan bukan
  verifikasi T1D v2.
- Validasi fisiologis terhadap data pasien dapat ditunda untuk tahap berikutnya,
  tetapi verifikasi matematis, satuan, dan perilaku dasar di atas tetap wajib.
- PID atau Artificial Pancreas tetap di luar ruang lingkup sampai mode basal-bolus
  manual selesai.

---

*Dokumen ini memuat model Mode Normal yang telah diverifikasi dan spesifikasi
riset awal Mode T1D open-loop. Artificial Pancreas/PID tetap menjadi tahap
terpisah setelah model T1D manual selesai dikalibrasi dan diverifikasi.*
